.. _envs:

.. automodule:: stable_baselines3.common.envs



Custom Environments
===================

Those environments were created for testing purposes.


BitFlippingEnv
--------------

.. autoclass:: BitFlippingEnv
  :members:


SimpleMultiObsEnv
-----------------

.. autoclass:: SimpleMultiObsEnv
  :members: